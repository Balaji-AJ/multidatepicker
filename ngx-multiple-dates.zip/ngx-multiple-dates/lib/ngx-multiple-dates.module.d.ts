import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './components/multiple-dates/multiple-dates.component';
import * as ɵngcc2 from '@angular/common';
import * as ɵngcc3 from '@angular/forms';
import * as ɵngcc4 from '@angular/material/chips';
import * as ɵngcc5 from '@angular/material/datepicker';
import * as ɵngcc6 from '@angular/material/form-field';
import * as ɵngcc7 from '@angular/material/icon';
import * as ɵngcc8 from '@angular/material/input';
export declare class NgxMultipleDatesModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgxMultipleDatesModule, [typeof ɵngcc1.MultipleDatesComponent], [typeof ɵngcc2.CommonModule, typeof ɵngcc3.ReactiveFormsModule, typeof ɵngcc4.MatChipsModule, typeof ɵngcc5.MatDatepickerModule, typeof ɵngcc6.MatFormFieldModule, typeof ɵngcc7.MatIconModule, typeof ɵngcc8.MatInputModule], [typeof ɵngcc1.MultipleDatesComponent]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgxMultipleDatesModule>;
}

//# sourceMappingURL=ngx-multiple-dates.module.d.ts.map