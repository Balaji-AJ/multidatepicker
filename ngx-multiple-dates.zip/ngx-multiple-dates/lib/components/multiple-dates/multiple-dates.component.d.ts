import { ChangeDetectorRef, AfterViewInit, OnDestroy, DoCheck, EventEmitter, ElementRef } from '@angular/core';
import { ControlValueAccessor, AbstractControl, NgControl, NgForm, FormGroupDirective, Validator, ValidationErrors } from '@angular/forms';
import { FocusMonitor } from '@angular/cdk/a11y';
import { BooleanInput } from '@angular/cdk/coercion';
import { DateAdapter, ThemePalette, CanUpdateErrorState, HasTabIndex, CanDisable, ErrorStateMatcher, HasTabIndexCtor, CanDisableCtor, CanUpdateErrorStateCtor } from '@angular/material/core';
import { MatDatepicker, MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MatFormFieldControl } from '@angular/material/form-field';
import { Subject } from 'rxjs';
import { DateClass } from '../../models/date-class.model';
import * as ɵngcc0 from '@angular/core';
declare class MultipleDatesBase {
    protected $elementRef: ElementRef<HTMLElement>;
    _defaultErrorStateMatcher: ErrorStateMatcher;
    _parentForm: NgForm;
    _parentFormGroup: FormGroupDirective;
    ngControl: NgControl;
    constructor($elementRef: ElementRef<HTMLElement>, _defaultErrorStateMatcher: ErrorStateMatcher, _parentForm: NgForm, _parentFormGroup: FormGroupDirective, ngControl: NgControl);
}
declare const _MultipleDatesBaseMixinBase: HasTabIndexCtor & CanDisableCtor & CanUpdateErrorStateCtor & typeof MultipleDatesBase;
/**
 * Multiple dates component.
 * @template D Date type.
 */
export declare class MultipleDatesComponent<D = Date> extends _MultipleDatesBaseMixinBase implements AfterViewInit, OnDestroy, DoCheck, ControlValueAccessor, MatFormFieldControl<D[]>, HasTabIndex, CanDisable, CanUpdateErrorState, Validator {
    ngControl: NgControl;
    protected $elementRef: ElementRef<HTMLElement>;
    private _changeDetectorRef;
    private _focusMonitor;
    private _dateAdapter;
    static nextId: number;
    static ngAcceptInputType_required: BooleanInput;
    static ngAcceptInputType_disabled: BooleanInput;
    static ngAcceptInputType_value: any[];
    id: string;
    describedBy: string;
    errorState: boolean;
    errorStateMatcher: ErrorStateMatcher;
    tabIndex: number;
    readonly dateChange: EventEmitter<MatDatepickerInputEvent<D, unknown>>;
    focused: boolean;
    controlType?: string | undefined;
    resetModel: Date;
    readonly stateChanges: Subject<void>;
    private readonly _destroy;
    private _matDatepicker;
    private _closeOnSelected;
    private _placeholder;
    private _required;
    private _disabled;
    private _value;
    private _color;
    private _dateFilter;
    private _min;
    private _max;
    private _classes;
    private _validator;
    private _onChange;
    private _onTouched;
    private _onValidatorChange;
    private _filterValidator;
    private _minValidator;
    private _maxValidator;
    get matDatepicker(): MatDatepicker<D>;
    set matDatepicker(value: MatDatepicker<D>);
    get closeOnSelected(): boolean;
    set closeOnSelected(value: boolean);
    get placeholder(): string;
    set placeholder(value: string);
    get required(): boolean;
    set required(value: boolean);
    get disabled(): boolean;
    set disabled(value: boolean);
    get value(): D[] | null;
    set value(value: D[] | null);
    get color(): ThemePalette | null;
    set color(value: ThemePalette | null);
    get matDatepickerFilter(): (date: D | null) => boolean;
    set matDatepickerFilter(value: (date: D | null) => boolean);
    get min(): D | null;
    set min(value: D | null);
    /** The maximum valid date. */
    get max(): D | null;
    set max(value: D | null);
    /** Custom date classes. */
    get classes(): Array<DateClass<D>>;
    set classes(value: Array<DateClass<D>>);
    get shouldLabelFloat(): boolean;
    get empty(): boolean;
    constructor(ngControl: NgControl, $elementRef: ElementRef<HTMLElement>, _changeDetectorRef: ChangeDetectorRef, _focusMonitor: FocusMonitor, _dateAdapter: DateAdapter<D>, parentForm: NgForm, parentFormGroup: FormGroupDirective, defaultErrorStateMatcher: ErrorStateMatcher, tabIndex: string);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    ngDoCheck(): void;
    focus(): void;
    blur(): void;
    writeValue(value: D[] | null): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    registerOnValidatorChange(fn: () => void): void;
    setDescribedByIds(ids: string[]): void;
    onContainerClick(): void;
    validate(control: AbstractControl): ValidationErrors | null;
    dateClass: (date: D) => string[];
    dateChanged(event: MatDatepickerInputEvent<D>): void;
    remove(date: D): void;
    trackByValue(_index: number, item: D): D;
    getClassName(value: D): string | undefined;
    private _setStartAt;
    private _setDisabled;
    private _setDateClass;
    private _find;
    private _sort;
    private _toNumber;
    private _getValidDateOrNull;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<MultipleDatesComponent<any>, [{ optional: true; self: true; }, null, null, null, { optional: true; }, { optional: true; }, { optional: true; }, null, { attribute: "tabindex"; }]>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<MultipleDatesComponent<any>, "ngx-multiple-dates", ["ngxMultipleDates"], { "id": "id"; "tabIndex": "tabIndex"; "matDatepicker": "matDatepicker"; "closeOnSelected": "closeOnSelected"; "placeholder": "placeholder"; "required": "required"; "disabled": "disabled"; "value": "value"; "color": "color"; "matDatepickerFilter": "matDatepickerFilter"; "min": "min"; "max": "max"; "classes": "classes"; "errorStateMatcher": "errorStateMatcher"; }, { "dateChange": "dateChange"; }, never, never>;
}
export {};

//# sourceMappingURL=multiple-dates.component.d.ts.map