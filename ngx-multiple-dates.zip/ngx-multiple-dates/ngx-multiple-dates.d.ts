/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';

//# sourceMappingURL=ngx-multiple-dates.d.ts.map