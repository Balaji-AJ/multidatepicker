(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/forms'), require('@angular/cdk/a11y'), require('@angular/cdk/coercion'), require('@angular/material/core'), require('@angular/material/datepicker'), require('@angular/material/form-field'), require('rxjs'), require('rxjs/operators'), require('@angular/common'), require('@angular/material/chips'), require('@angular/material/icon'), require('@angular/material/input')) :
    typeof define === 'function' && define.amd ? define('ngx-multiple-dates', ['exports', '@angular/core', '@angular/forms', '@angular/cdk/a11y', '@angular/cdk/coercion', '@angular/material/core', '@angular/material/datepicker', '@angular/material/form-field', 'rxjs', 'rxjs/operators', '@angular/common', '@angular/material/chips', '@angular/material/icon', '@angular/material/input'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global['ngx-multiple-dates'] = {}, global.ng.core, global.ng.forms, global.ng.cdk.a11y, global.ng.cdk.coercion, global.ng.material.core, global.ng.material.datepicker, global.ng.material.formField, global.rxjs, global.rxjs.operators, global.ng.common, global.ng.material.chips, global.ng.material.icon, global.ng.material.input));
}(this, (function (exports, core$1, forms, a11y, coercion, core, datepicker, formField, rxjs, operators, common, chips, icon, input) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function () { return m[k]; } });
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, o) {
        for (var p in m)
            if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
                __createBinding(o, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    /** @deprecated */
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    /** @deprecated */
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    function __spreadArray(to, from) {
        for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
            to[j] = from[i];
        return to;
    }
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }
    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    var MultipleDatesBase = /** @class */ (function () {
        function MultipleDatesBase($elementRef, _defaultErrorStateMatcher, _parentForm, _parentFormGroup, ngControl) {
            this.$elementRef = $elementRef;
            this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
            this._parentForm = _parentForm;
            this._parentFormGroup = _parentFormGroup;
            this.ngControl = ngControl;
        }
        return MultipleDatesBase;
    }());
    var _MultipleDatesBaseMixinBase = core.mixinTabIndex(core.mixinDisabled(core.mixinErrorState(MultipleDatesBase)));
    /**
     * Multiple dates component.
     * @template D Date type.
     */
    var MultipleDatesComponent = /** @class */ (function (_super) {
        __extends(MultipleDatesComponent, _super);
        function MultipleDatesComponent(ngControl, $elementRef, _changeDetectorRef, _focusMonitor, _dateAdapter, parentForm, parentFormGroup, defaultErrorStateMatcher, tabIndex) {
            var _this = _super.call(this, $elementRef, defaultErrorStateMatcher, parentForm, parentFormGroup, ngControl) || this;
            _this.ngControl = ngControl;
            _this.$elementRef = $elementRef;
            _this._changeDetectorRef = _changeDetectorRef;
            _this._focusMonitor = _focusMonitor;
            _this._dateAdapter = _dateAdapter;
            _this.id = "ngx-multiple-dates-" + MultipleDatesComponent.nextId++;
            _this.describedBy = '';
            _this.errorState = false;
            _this.dateChange = new core$1.EventEmitter();
            _this.focused = false;
            _this.controlType = 'ngx-multiple-dates';
            _this.resetModel = new Date(0);
            _this.stateChanges = new rxjs.Subject();
            _this._destroy = new rxjs.Subject();
            _this._closeOnSelected = false;
            _this._required = false;
            _this._disabled = false;
            _this._value = [];
            _this._color = null;
            _this._classes = [];
            _this._onChange = function () { };
            _this._onTouched = function () { };
            _this._onValidatorChange = function () { };
            _this._filterValidator = function (control) {
                var value = _this._getValidDateOrNull(_this._dateAdapter.deserialize(control.value));
                return !_this._dateFilter || !value || _this._dateFilter(value)
                    ? null
                    : { matDatepickerFilter: true };
            };
            _this._minValidator = function (control) {
                var value = _this._getValidDateOrNull(_this._dateAdapter.deserialize(control.value));
                return (!_this.min || !value || _this._dateAdapter.compareDate(_this.min, value) <= 0)
                    ? null
                    : { matDatepickerMin: { min: _this.min, actual: value } };
            };
            _this._maxValidator = function (control) {
                var value = _this._getValidDateOrNull(_this._dateAdapter.deserialize(control.value));
                return (!_this.max || !value || _this._dateAdapter.compareDate(_this.max, value) >= 0)
                    ? null
                    : { matDatepickerMax: { max: _this.max, actual: value } };
            };
            _this.dateClass = function (date) {
                var className;
                if (_this.classes.length) {
                    className = _this.getClassName(date);
                }
                if (_this._find(date) !== -1) {
                    return __spread(['selected'], (className ? [className] : []));
                }
                if (className) {
                    return [className];
                }
                return [];
            };
            var validators = [
                _this._filterValidator,
                _this._minValidator,
                _this._maxValidator
            ];
            if (_this.ngControl != null) {
                _this.ngControl.valueAccessor = _this;
                if (_this.ngControl.validator) {
                    validators.push(_this.ngControl.validator);
                }
            }
            _this._validator = forms.Validators.compose(validators);
            _focusMonitor.monitor($elementRef.nativeElement, true)
                .subscribe(function (origin) {
                _this.focused = !!origin;
                _this.stateChanges.next();
            });
            _this.tabIndex = Number(tabIndex) || 0;
            return _this;
        }
        Object.defineProperty(MultipleDatesComponent.prototype, "matDatepicker", {
            get: function () {
                return this._matDatepicker;
            },
            set: function (value) {
                var _this = this;
                if (!value || !(value instanceof datepicker.MatDatepicker)) {
                    throw new TypeError("\"matDatepicker\" attribute of \"ngx-multiple-dates\" is required and should be an instance of\n        Angular Material Datepicker component.");
                }
                this._matDatepicker = value;
                this.matDatepicker.closedStream
                    .pipe(operators.takeUntil(this._destroy))
                    .subscribe(function () { return _this.blur(); });
                if (!this.matDatepicker.startAt) {
                    this._setStartAt();
                }
                this._setDisabled();
                this._setDateClass();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "closeOnSelected", {
            get: function () {
                return this._closeOnSelected;
            },
            set: function (value) {
                this._closeOnSelected = coercion.coerceBooleanProperty(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "placeholder", {
            get: function () {
                return this._placeholder;
            },
            set: function (value) {
                this._placeholder = value;
                this.stateChanges.next();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "required", {
            get: function () {
                return this._required;
            },
            set: function (value) {
                this._required = coercion.coerceBooleanProperty(value);
                this.stateChanges.next();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "disabled", {
            get: function () {
                // if (this.ngControl && this.ngControl.disabled !== null) {
                //   return this.ngControl.disabled;
                // }
                return this._disabled;
            },
            set: function (value) {
                this._disabled = coercion.coerceBooleanProperty(value);
                this._setDisabled();
                if (this.focused) {
                    this.focused = false;
                    this.stateChanges.next();
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "value", {
            get: function () {
                if (!this._value) {
                    this._value = [];
                }
                return this._value;
            },
            set: function (value) {
                if (value !== this._value) {
                    this.writeValue(value);
                }
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "color", {
            get: function () {
                return this._color;
            },
            set: function (value) {
                this._color = value;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "matDatepickerFilter", {
            get: function () {
                return this._dateFilter;
            },
            set: function (value) {
                this._dateFilter = value;
                this._onValidatorChange();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "min", {
            get: function () {
                return this._min;
            },
            set: function (value) {
                this._min = this._getValidDateOrNull(this._dateAdapter.deserialize(value));
                this._onValidatorChange();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "max", {
            /** The maximum valid date. */
            get: function () {
                return this._max;
            },
            set: function (value) {
                this._max = this._getValidDateOrNull(this._dateAdapter.deserialize(value));
                this._onValidatorChange();
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "classes", {
            /** Custom date classes. */
            get: function () {
                return this._classes;
            },
            set: function (value) {
                this._classes = coercion.coerceArray(value);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "shouldLabelFloat", {
            get: function () {
                return !this.empty || (this.focused && !this.disabled);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(MultipleDatesComponent.prototype, "empty", {
            get: function () {
                return !this.value || !this.value.length;
            },
            enumerable: false,
            configurable: true
        });
        MultipleDatesComponent.prototype.ngAfterViewInit = function () {
            if (this.ngControl && this.ngControl.control) {
                this.ngControl.control.setValidators(this.validate.bind(this));
            }
            this._setStartAt();
            this._setDateClass();
        };
        MultipleDatesComponent.prototype.ngOnDestroy = function () {
            this._destroy.next();
            this._destroy.complete();
            this.stateChanges.complete();
            this._focusMonitor.stopMonitoring(this.$elementRef.nativeElement);
        };
        MultipleDatesComponent.prototype.ngDoCheck = function () {
            if (this.ngControl) {
                this.updateErrorState();
            }
        };
        MultipleDatesComponent.prototype.focus = function () {
            if (!this.disabled) {
                this.focused = true;
                if (this.matDatepicker) {
                    this.matDatepicker.open();
                }
                // this._changeDetectorRef.markForCheck();
                this.stateChanges.next();
            }
        };
        MultipleDatesComponent.prototype.blur = function () {
            this.focused = false;
            if (!this.disabled) {
                this._onTouched();
                // if (this.matDatepicker && this.matDatepicker.opened) {
                //   this.matDatepicker.close();
                // }
                this._changeDetectorRef.markForCheck();
                this.stateChanges.next();
            }
        };
        MultipleDatesComponent.prototype.writeValue = function (value) {
            if (Array.isArray(value)) {
                this._value = __spread(value);
                this._sort();
            }
            else {
                this._value = value;
            }
            this._onChange(value);
            this.stateChanges.next();
        };
        MultipleDatesComponent.prototype.registerOnChange = function (fn) {
            this._onChange = fn;
        };
        MultipleDatesComponent.prototype.registerOnTouched = function (fn) {
            this._onTouched = fn;
        };
        MultipleDatesComponent.prototype.registerOnValidatorChange = function (fn) {
            this._onValidatorChange = fn;
        };
        MultipleDatesComponent.prototype.setDescribedByIds = function (ids) {
            this.describedBy = ids.join(' ');
        };
        MultipleDatesComponent.prototype.onContainerClick = function () {
            if (!this.focused) {
                this.focus();
            }
        };
        MultipleDatesComponent.prototype.validate = function (control) {
            return this._validator ? this._validator(control) : null;
        };
        MultipleDatesComponent.prototype.dateChanged = function (event) {
            var _this = this;
            if (event.value) {
                var date = event.value;
                if (this.value) {
                    var index = this._find(date);
                    if (index === -1) {
                        this.value.push(date);
                        this._sort();
                    }
                    else {
                        this.value.splice(index, 1);
                    }
                }
                this.resetModel = new Date(0);
                this._setStartAt();
                if (this.matDatepicker && !this.closeOnSelected) {
                    var closeFn_1 = this.matDatepicker.close;
                    this.matDatepicker.close = function () { };
                    // tslint:disable-next-line:no-string-literal
                    this.matDatepicker['_popupComponentRef'].instance._calendar.monthView._createWeekCells();
                    setTimeout(function () { return _this.matDatepicker.close = closeFn_1; });
                    this._changeDetectorRef.detectChanges();
                }
                this.writeValue(this.value);
            }
            this.dateChange.emit(event);
        };
        MultipleDatesComponent.prototype.remove = function (date) {
            if (this.value && this.value.length) {
                this._onTouched();
                var index = this._find(date);
                this.value.splice(index, 1);
                this.writeValue(this.value);
                this._changeDetectorRef.detectChanges();
            }
        };
        MultipleDatesComponent.prototype.trackByValue = function (_index, item) {
            return item;
        };
        MultipleDatesComponent.prototype.getClassName = function (value) {
            var e_1, _a;
            try {
                for (var _b = __values(this.classes), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var classValue = _c.value;
                    if (this._dateAdapter.compareDate(classValue.value, value) === 0) {
                        return classValue.className;
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
            return undefined;
        };
        MultipleDatesComponent.prototype._setStartAt = function () {
            if (this.matDatepicker) {
                if (this.value && this.value.length) {
                    this.matDatepicker.startAt = this.value[this.value.length - 1];
                }
                else {
                    this.matDatepicker.startAt = new Date();
                }
            }
        };
        MultipleDatesComponent.prototype._setDisabled = function () {
            if (this.matDatepicker) {
                this.matDatepicker.disabled = this.disabled;
            }
        };
        MultipleDatesComponent.prototype._setDateClass = function () {
            var _this = this;
            if (this.matDatepicker) {
                var dateClassFn_1 = this.matDatepicker.dateClass;
                this.matDatepicker.dateClass = function (date) {
                    var e_2, _a, e_3, _b, e_4, _c;
                    var classList = _this.dateClass(date);
                    if (dateClassFn_1) {
                        var oldClasses = dateClassFn_1(date, 'month');
                        if (classList.length) {
                            if (oldClasses instanceof Set) {
                                try {
                                    for (var classList_1 = __values(classList), classList_1_1 = classList_1.next(); !classList_1_1.done; classList_1_1 = classList_1.next()) {
                                        var className = classList_1_1.value;
                                        oldClasses.add(className);
                                    }
                                }
                                catch (e_2_1) { e_2 = { error: e_2_1 }; }
                                finally {
                                    try {
                                        if (classList_1_1 && !classList_1_1.done && (_a = classList_1.return)) _a.call(classList_1);
                                    }
                                    finally { if (e_2) throw e_2.error; }
                                }
                            }
                            else if (oldClasses instanceof Array) {
                                try {
                                    for (var classList_2 = __values(classList), classList_2_1 = classList_2.next(); !classList_2_1.done; classList_2_1 = classList_2.next()) {
                                        var className = classList_2_1.value;
                                        oldClasses.push(className);
                                    }
                                }
                                catch (e_3_1) { e_3 = { error: e_3_1 }; }
                                finally {
                                    try {
                                        if (classList_2_1 && !classList_2_1.done && (_b = classList_2.return)) _b.call(classList_2);
                                    }
                                    finally { if (e_3) throw e_3.error; }
                                }
                            }
                            else if (typeof ('t') === 'string') {
                                return __spread([oldClasses], classList).join(' ');
                            }
                            else {
                                try {
                                    for (var classList_3 = __values(classList), classList_3_1 = classList_3.next(); !classList_3_1.done; classList_3_1 = classList_3.next()) {
                                        var className = classList_3_1.value;
                                        oldClasses[className] = className;
                                    }
                                }
                                catch (e_4_1) { e_4 = { error: e_4_1 }; }
                                finally {
                                    try {
                                        if (classList_3_1 && !classList_3_1.done && (_c = classList_3.return)) _c.call(classList_3);
                                    }
                                    finally { if (e_4) throw e_4.error; }
                                }
                            }
                            return oldClasses;
                        }
                        return oldClasses;
                    }
                    return classList;
                };
            }
        };
        MultipleDatesComponent.prototype._find = function (date) {
            var _this = this;
            if (!this.value) {
                return -1;
            }
            return this.value.map(function (value) { return _this._toNumber(value); }).indexOf(this._toNumber(date));
        };
        MultipleDatesComponent.prototype._sort = function () {
            var _this = this;
            if (this.value) {
                this.value.sort(function (lhs, rhs) { return _this._toNumber(lhs) - _this._toNumber(rhs); });
            }
        };
        MultipleDatesComponent.prototype._toNumber = function (date) {
            if (date instanceof Date) {
                return +date;
            }
            else {
                var momentLike = date;
                if (momentLike.toDate && momentLike.toDate instanceof Function) {
                    return +momentLike.toDate();
                }
                else {
                    throw new TypeError('Unknown type. It can be either Date or Moment.');
                }
            }
        };
        MultipleDatesComponent.prototype._getValidDateOrNull = function (obj) {
            return (this._dateAdapter.isDateInstance(obj) && this._dateAdapter.isValid(obj)) ? obj : null;
        };
        return MultipleDatesComponent;
    }(_MultipleDatesBaseMixinBase));
    MultipleDatesComponent.nextId = 0;
    MultipleDatesComponent.decorators = [
        { type: core$1.Component, args: [{
                    selector: 'ngx-multiple-dates',
                    template: "<mat-chip-list #chipList aria-label=\"placeholder\" [selectable]=\"false\"\r\n               (click)=\"focus()\">\r\n  <mat-chip *ngFor=\"let item of value; trackBy: trackByValue;\" removable (removed)=\"remove(item)\"\r\n            [color]=\"color\" [selected]=\"color\" [ngClass]='getClassName(item)'>\r\n    {{ item | date }}\r\n    <mat-icon matChipRemove>cancel</mat-icon>\r\n  </mat-chip>\r\n  <input matInput hidden [value]=\"resetModel\"\r\n         [matDatepicker]=\"matDatepicker\" [matDatepickerFilter]=\"matDatepickerFilter\"\r\n         [min]=\"min\" [max]=\"max\" [matChipInputFor]=\"chipList\" (dateChange)=\"dateChanged($event)\" />\r\n</mat-chip-list>\r\n",
                    providers: [
                        { provide: formField.MatFormFieldControl, useExisting: MultipleDatesComponent }
                    ],
                    exportAs: 'ngxMultipleDates',
                    styles: [":host{display:block;outline:none!important}:host span{opacity:0;transition:opacity .2s}:host.floating span{opacity:1}:host ::ng-deep mat-chip-list{outline:none!important}:host ::ng-deep mat-chip-list .mat-chip-list-wrapper{min-height:18px}:host ::ng-deep mat-chip-list .mat-chip-remove{outline:none!important}"]
                },] }
    ];
    MultipleDatesComponent.ctorParameters = function () { return [
        { type: forms.NgControl, decorators: [{ type: core$1.Optional }, { type: core$1.Self }] },
        { type: core$1.ElementRef },
        { type: core$1.ChangeDetectorRef },
        { type: a11y.FocusMonitor },
        { type: core.DateAdapter, decorators: [{ type: core$1.Optional }] },
        { type: forms.NgForm, decorators: [{ type: core$1.Optional }] },
        { type: forms.FormGroupDirective, decorators: [{ type: core$1.Optional }] },
        { type: core.ErrorStateMatcher },
        { type: String, decorators: [{ type: core$1.Attribute, args: ['tabindex',] }] }
    ]; };
    MultipleDatesComponent.propDecorators = {
        id: [{ type: core$1.Input }, { type: core$1.HostBinding }],
        describedBy: [{ type: core$1.HostBinding, args: ['attr.aria-describedby',] }],
        errorState: [{ type: core$1.HostBinding, args: ['attr.aria-invalid',] }, { type: core$1.HostBinding, args: ['class.mat-form-field-invalid',] }],
        errorStateMatcher: [{ type: core$1.Input }],
        tabIndex: [{ type: core$1.Input }, { type: core$1.HostBinding, args: ['attr.tabindex',] }],
        dateChange: [{ type: core$1.Output }],
        matDatepicker: [{ type: core$1.Input }],
        closeOnSelected: [{ type: core$1.Input }],
        placeholder: [{ type: core$1.Input }, { type: core$1.HostBinding, args: ['attr.aria-label',] }],
        required: [{ type: core$1.Input }, { type: core$1.HostBinding, args: ['attr.aria-required',] }],
        disabled: [{ type: core$1.Input }, { type: core$1.HostBinding, args: ['attr.disabled',] }],
        value: [{ type: core$1.Input }],
        color: [{ type: core$1.Input }],
        matDatepickerFilter: [{ type: core$1.Input }],
        min: [{ type: core$1.Input }],
        max: [{ type: core$1.Input }],
        classes: [{ type: core$1.Input }],
        shouldLabelFloat: [{ type: core$1.HostBinding, args: ['class.floating',] }],
        focus: [{ type: core$1.HostListener, args: ['focus',] }],
        blur: [{ type: core$1.HostListener, args: ['blur',] }]
    };

    /**
     * Date class item.
     * @template D Date type.
     */
    var DateClass = /** @class */ (function () {
        function DateClass() {
        }
        return DateClass;
    }());

    var NgxMultipleDatesModule = /** @class */ (function () {
        function NgxMultipleDatesModule() {
        }
        return NgxMultipleDatesModule;
    }());
    NgxMultipleDatesModule.decorators = [
        { type: core$1.NgModule, args: [{
                    declarations: [MultipleDatesComponent],
                    imports: [
                        common.CommonModule,
                        forms.ReactiveFormsModule,
                        chips.MatChipsModule,
                        datepicker.MatDatepickerModule,
                        formField.MatFormFieldModule,
                        icon.MatIconModule,
                        input.MatInputModule
                    ],
                    exports: [MultipleDatesComponent]
                },] }
    ];

    /*
     * Public API Surface of ngx-multiple-dates
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.DateClass = DateClass;
    exports.MultipleDatesComponent = MultipleDatesComponent;
    exports.NgxMultipleDatesModule = NgxMultipleDatesModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ngx-multiple-dates.umd.js.map
