import { EventEmitter, Component, Optional, Self, ElementRef, ChangeDetectorRef, Attribute, Input, HostBinding, Output, HostListener, NgModule } from '@angular/core';
import { Validators, NgControl, NgForm, FormGroupDirective, ReactiveFormsModule } from '@angular/forms';
import { FocusMonitor } from '@angular/cdk/a11y';
import { coerceBooleanProperty, coerceArray } from '@angular/cdk/coercion';
import { mixinTabIndex, mixinDisabled, mixinErrorState, DateAdapter, ErrorStateMatcher } from '@angular/material/core';
import { MatDatepicker, MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldControl, MatFormFieldModule } from '@angular/material/form-field';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';

class MultipleDatesBase {
    constructor($elementRef, _defaultErrorStateMatcher, _parentForm, _parentFormGroup, ngControl) {
        this.$elementRef = $elementRef;
        this._defaultErrorStateMatcher = _defaultErrorStateMatcher;
        this._parentForm = _parentForm;
        this._parentFormGroup = _parentFormGroup;
        this.ngControl = ngControl;
    }
}
const _MultipleDatesBaseMixinBase = mixinTabIndex(mixinDisabled(mixinErrorState(MultipleDatesBase)));
/**
 * Multiple dates component.
 * @template D Date type.
 */
class MultipleDatesComponent extends _MultipleDatesBaseMixinBase {
    constructor(ngControl, $elementRef, _changeDetectorRef, _focusMonitor, _dateAdapter, parentForm, parentFormGroup, defaultErrorStateMatcher, tabIndex) {
        super($elementRef, defaultErrorStateMatcher, parentForm, parentFormGroup, ngControl);
        this.ngControl = ngControl;
        this.$elementRef = $elementRef;
        this._changeDetectorRef = _changeDetectorRef;
        this._focusMonitor = _focusMonitor;
        this._dateAdapter = _dateAdapter;
        this.id = `ngx-multiple-dates-${MultipleDatesComponent.nextId++}`;
        this.describedBy = '';
        this.errorState = false;
        this.dateChange = new EventEmitter();
        this.focused = false;
        this.controlType = 'ngx-multiple-dates';
        this.resetModel = new Date(0);
        this.stateChanges = new Subject();
        this._destroy = new Subject();
        this._closeOnSelected = false;
        this._required = false;
        this._disabled = false;
        this._value = [];
        this._color = null;
        this._classes = [];
        this._onChange = () => { };
        this._onTouched = () => { };
        this._onValidatorChange = () => { };
        this._filterValidator = (control) => {
            const value = this._getValidDateOrNull(this._dateAdapter.deserialize(control.value));
            return !this._dateFilter || !value || this._dateFilter(value)
                ? null
                : { matDatepickerFilter: true };
        };
        this._minValidator = (control) => {
            const value = this._getValidDateOrNull(this._dateAdapter.deserialize(control.value));
            return (!this.min || !value || this._dateAdapter.compareDate(this.min, value) <= 0)
                ? null
                : { matDatepickerMin: { min: this.min, actual: value } };
        };
        this._maxValidator = (control) => {
            const value = this._getValidDateOrNull(this._dateAdapter.deserialize(control.value));
            return (!this.max || !value || this._dateAdapter.compareDate(this.max, value) >= 0)
                ? null
                : { matDatepickerMax: { max: this.max, actual: value } };
        };
        this.dateClass = (date) => {
            let className;
            if (this.classes.length) {
                className = this.getClassName(date);
            }
            if (this._find(date) !== -1) {
                return ['selected', ...(className ? [className] : [])];
            }
            if (className) {
                return [className];
            }
            return [];
        };
        const validators = [
            this._filterValidator,
            this._minValidator,
            this._maxValidator
        ];
        if (this.ngControl != null) {
            this.ngControl.valueAccessor = this;
            if (this.ngControl.validator) {
                validators.push(this.ngControl.validator);
            }
        }
        this._validator = Validators.compose(validators);
        _focusMonitor.monitor($elementRef.nativeElement, true)
            .subscribe((origin) => {
            this.focused = !!origin;
            this.stateChanges.next();
        });
        this.tabIndex = Number(tabIndex) || 0;
    }
    get matDatepicker() {
        return this._matDatepicker;
    }
    set matDatepicker(value) {
        if (!value || !(value instanceof MatDatepicker)) {
            throw new TypeError(`"matDatepicker" attribute of "ngx-multiple-dates" is required and should be an instance of
        Angular Material Datepicker component.`);
        }
        this._matDatepicker = value;
        this.matDatepicker.closedStream
            .pipe(takeUntil(this._destroy))
            .subscribe(() => this.blur());
        if (!this.matDatepicker.startAt) {
            this._setStartAt();
        }
        this._setDisabled();
        this._setDateClass();
    }
    get closeOnSelected() {
        return this._closeOnSelected;
    }
    set closeOnSelected(value) {
        this._closeOnSelected = coerceBooleanProperty(value);
    }
    get placeholder() {
        return this._placeholder;
    }
    set placeholder(value) {
        this._placeholder = value;
        this.stateChanges.next();
    }
    get required() {
        return this._required;
    }
    set required(value) {
        this._required = coerceBooleanProperty(value);
        this.stateChanges.next();
    }
    get disabled() {
        // if (this.ngControl && this.ngControl.disabled !== null) {
        //   return this.ngControl.disabled;
        // }
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
        this._setDisabled();
        if (this.focused) {
            this.focused = false;
            this.stateChanges.next();
        }
    }
    get value() {
        if (!this._value) {
            this._value = [];
        }
        return this._value;
    }
    set value(value) {
        if (value !== this._value) {
            this.writeValue(value);
        }
    }
    get color() {
        return this._color;
    }
    set color(value) {
        this._color = value;
    }
    get matDatepickerFilter() {
        return this._dateFilter;
    }
    set matDatepickerFilter(value) {
        this._dateFilter = value;
        this._onValidatorChange();
    }
    get min() {
        return this._min;
    }
    set min(value) {
        this._min = this._getValidDateOrNull(this._dateAdapter.deserialize(value));
        this._onValidatorChange();
    }
    /** The maximum valid date. */
    get max() {
        return this._max;
    }
    set max(value) {
        this._max = this._getValidDateOrNull(this._dateAdapter.deserialize(value));
        this._onValidatorChange();
    }
    /** Custom date classes. */
    get classes() {
        return this._classes;
    }
    set classes(value) {
        this._classes = coerceArray(value);
    }
    get shouldLabelFloat() {
        return !this.empty || (this.focused && !this.disabled);
    }
    get empty() {
        return !this.value || !this.value.length;
    }
    ngAfterViewInit() {
        if (this.ngControl && this.ngControl.control) {
            this.ngControl.control.setValidators(this.validate.bind(this));
        }
        this._setStartAt();
        this._setDateClass();
    }
    ngOnDestroy() {
        this._destroy.next();
        this._destroy.complete();
        this.stateChanges.complete();
        this._focusMonitor.stopMonitoring(this.$elementRef.nativeElement);
    }
    ngDoCheck() {
        if (this.ngControl) {
            this.updateErrorState();
        }
    }
    focus() {
        if (!this.disabled) {
            this.focused = true;
            if (this.matDatepicker) {
                this.matDatepicker.open();
            }
            // this._changeDetectorRef.markForCheck();
            this.stateChanges.next();
        }
    }
    blur() {
        this.focused = false;
        if (!this.disabled) {
            this._onTouched();
            // if (this.matDatepicker && this.matDatepicker.opened) {
            //   this.matDatepicker.close();
            // }
            this._changeDetectorRef.markForCheck();
            this.stateChanges.next();
        }
    }
    writeValue(value) {
        if (Array.isArray(value)) {
            this._value = [...value];
            this._sort();
        }
        else {
            this._value = value;
        }
        this._onChange(value);
        this.stateChanges.next();
    }
    registerOnChange(fn) {
        this._onChange = fn;
    }
    registerOnTouched(fn) {
        this._onTouched = fn;
    }
    registerOnValidatorChange(fn) {
        this._onValidatorChange = fn;
    }
    setDescribedByIds(ids) {
        this.describedBy = ids.join(' ');
    }
    onContainerClick() {
        if (!this.focused) {
            this.focus();
        }
    }
    validate(control) {
        return this._validator ? this._validator(control) : null;
    }
    dateChanged(event) {
        if (event.value) {
            const date = event.value;
            if (this.value) {
                const index = this._find(date);
                if (index === -1) {
                    this.value.push(date);
                    this._sort();
                }
                else {
                    this.value.splice(index, 1);
                }
            }
            this.resetModel = new Date(0);
            this._setStartAt();
            if (this.matDatepicker && !this.closeOnSelected) {
                const closeFn = this.matDatepicker.close;
                this.matDatepicker.close = () => { };
                // tslint:disable-next-line:no-string-literal
                this.matDatepicker['_popupComponentRef'].instance._calendar.monthView._createWeekCells();
                setTimeout(() => this.matDatepicker.close = closeFn);
                this._changeDetectorRef.detectChanges();
            }
            this.writeValue(this.value);
        }
        this.dateChange.emit(event);
    }
    remove(date) {
        if (this.value && this.value.length) {
            this._onTouched();
            const index = this._find(date);
            this.value.splice(index, 1);
            this.writeValue(this.value);
            this._changeDetectorRef.detectChanges();
        }
    }
    trackByValue(_index, item) {
        return item;
    }
    getClassName(value) {
        for (const classValue of this.classes) {
            if (this._dateAdapter.compareDate(classValue.value, value) === 0) {
                return classValue.className;
            }
        }
        return undefined;
    }
    _setStartAt() {
        if (this.matDatepicker) {
            if (this.value && this.value.length) {
                this.matDatepicker.startAt = this.value[this.value.length - 1];
            }
            else {
                this.matDatepicker.startAt = new Date();
            }
        }
    }
    _setDisabled() {
        if (this.matDatepicker) {
            this.matDatepicker.disabled = this.disabled;
        }
    }
    _setDateClass() {
        if (this.matDatepicker) {
            const dateClassFn = this.matDatepicker.dateClass;
            this.matDatepicker.dateClass = (date) => {
                const classList = this.dateClass(date);
                if (dateClassFn) {
                    const oldClasses = dateClassFn(date, 'month');
                    if (classList.length) {
                        if (oldClasses instanceof Set) {
                            for (const className of classList) {
                                oldClasses.add(className);
                            }
                        }
                        else if (oldClasses instanceof Array) {
                            for (const className of classList) {
                                oldClasses.push(className);
                            }
                        }
                        else if (typeof ('t') === 'string') {
                            return [oldClasses, ...classList].join(' ');
                        }
                        else {
                            for (const className of classList) {
                                oldClasses[className] = className;
                            }
                        }
                        return oldClasses;
                    }
                    return oldClasses;
                }
                return classList;
            };
        }
    }
    _find(date) {
        if (!this.value) {
            return -1;
        }
        return this.value.map((value) => this._toNumber(value)).indexOf(this._toNumber(date));
    }
    _sort() {
        if (this.value) {
            this.value.sort((lhs, rhs) => this._toNumber(lhs) - this._toNumber(rhs));
        }
    }
    _toNumber(date) {
        if (date instanceof Date) {
            return +date;
        }
        else {
            const momentLike = date;
            if (momentLike.toDate && momentLike.toDate instanceof Function) {
                return +momentLike.toDate();
            }
            else {
                throw new TypeError('Unknown type. It can be either Date or Moment.');
            }
        }
    }
    _getValidDateOrNull(obj) {
        return (this._dateAdapter.isDateInstance(obj) && this._dateAdapter.isValid(obj)) ? obj : null;
    }
}
MultipleDatesComponent.nextId = 0;
MultipleDatesComponent.decorators = [
    { type: Component, args: [{
                selector: 'ngx-multiple-dates',
                template: "<mat-chip-list #chipList aria-label=\"placeholder\" [selectable]=\"false\"\r\n               (click)=\"focus()\">\r\n  <mat-chip *ngFor=\"let item of value; trackBy: trackByValue;\" removable (removed)=\"remove(item)\"\r\n            [color]=\"color\" [selected]=\"color\" [ngClass]='getClassName(item)'>\r\n    {{ item | date }}\r\n    <mat-icon matChipRemove>cancel</mat-icon>\r\n  </mat-chip>\r\n  <input matInput hidden [value]=\"resetModel\"\r\n         [matDatepicker]=\"matDatepicker\" [matDatepickerFilter]=\"matDatepickerFilter\"\r\n         [min]=\"min\" [max]=\"max\" [matChipInputFor]=\"chipList\" (dateChange)=\"dateChanged($event)\" />\r\n</mat-chip-list>\r\n",
                providers: [
                    { provide: MatFormFieldControl, useExisting: MultipleDatesComponent }
                ],
                exportAs: 'ngxMultipleDates',
                styles: [":host{display:block;outline:none!important}:host span{opacity:0;transition:opacity .2s}:host.floating span{opacity:1}:host ::ng-deep mat-chip-list{outline:none!important}:host ::ng-deep mat-chip-list .mat-chip-list-wrapper{min-height:18px}:host ::ng-deep mat-chip-list .mat-chip-remove{outline:none!important}"]
            },] }
];
MultipleDatesComponent.ctorParameters = () => [
    { type: NgControl, decorators: [{ type: Optional }, { type: Self }] },
    { type: ElementRef },
    { type: ChangeDetectorRef },
    { type: FocusMonitor },
    { type: DateAdapter, decorators: [{ type: Optional }] },
    { type: NgForm, decorators: [{ type: Optional }] },
    { type: FormGroupDirective, decorators: [{ type: Optional }] },
    { type: ErrorStateMatcher },
    { type: String, decorators: [{ type: Attribute, args: ['tabindex',] }] }
];
MultipleDatesComponent.propDecorators = {
    id: [{ type: Input }, { type: HostBinding }],
    describedBy: [{ type: HostBinding, args: ['attr.aria-describedby',] }],
    errorState: [{ type: HostBinding, args: ['attr.aria-invalid',] }, { type: HostBinding, args: ['class.mat-form-field-invalid',] }],
    errorStateMatcher: [{ type: Input }],
    tabIndex: [{ type: Input }, { type: HostBinding, args: ['attr.tabindex',] }],
    dateChange: [{ type: Output }],
    matDatepicker: [{ type: Input }],
    closeOnSelected: [{ type: Input }],
    placeholder: [{ type: Input }, { type: HostBinding, args: ['attr.aria-label',] }],
    required: [{ type: Input }, { type: HostBinding, args: ['attr.aria-required',] }],
    disabled: [{ type: Input }, { type: HostBinding, args: ['attr.disabled',] }],
    value: [{ type: Input }],
    color: [{ type: Input }],
    matDatepickerFilter: [{ type: Input }],
    min: [{ type: Input }],
    max: [{ type: Input }],
    classes: [{ type: Input }],
    shouldLabelFloat: [{ type: HostBinding, args: ['class.floating',] }],
    focus: [{ type: HostListener, args: ['focus',] }],
    blur: [{ type: HostListener, args: ['blur',] }]
};

/**
 * Date class item.
 * @template D Date type.
 */
class DateClass {
}

class NgxMultipleDatesModule {
}
NgxMultipleDatesModule.decorators = [
    { type: NgModule, args: [{
                declarations: [MultipleDatesComponent],
                imports: [
                    CommonModule,
                    ReactiveFormsModule,
                    MatChipsModule,
                    MatDatepickerModule,
                    MatFormFieldModule,
                    MatIconModule,
                    MatInputModule
                ],
                exports: [MultipleDatesComponent]
            },] }
];

/*
 * Public API Surface of ngx-multiple-dates
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DateClass, MultipleDatesComponent, NgxMultipleDatesModule };
//# sourceMappingURL=ngx-multiple-dates.js.map
