export const EMPLOYEES = [
  [
    "Greg Black",
    4.66,
    "=B1*1.3",
    "=AVERAGE(B1:C1)",
    "=SUM(B1:C1)"
  ],
  [
    "Anne Carpenter",
    5.25,
    "=$B$2*30%",
    "=AVERAGE(B2:C2)",
    "=SUM(B2:C2)"
  ],
  [
    "Natalie Dem",
    3.59,
    "=B3*2.7+2+1",
    "=AVERAGE(B3:C3)",
    "=SUM(B3:C3)"
  ],
  [
    "John Sieg",
    12.51,
    "=B4*(1.22+1)",
    "=AVERAGE(B4:C4)",
    "=SUM(B4:C4)"
  ],
  [
    "Chris Aklips",
    7.63,
    "=B5*1.1*SUM(10,20)+1",
    "=AVERAGE(B5:C5)",
    "=SUM(B5:C5)"
  ]
];
