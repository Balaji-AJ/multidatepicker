import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';



import { AppButton } from './app-button/app-button.component';
import { AppComponent } from './app.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatNativeDateModule, } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatIconModule } from '@angular/material/icon';
import { NgxMultipleDatesModule } from 'ngx-multiple-dates'; // module import
import { MatFormFieldModule} from '@angular/material/form-field';


@NgModule({
  declarations: [
    AppButton,
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatIconModule,
    NgxMultipleDatesModule,
    MatFormFieldModule
  ],
  exports: [
      MatDatepickerModule, 
      MatNativeDateModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
