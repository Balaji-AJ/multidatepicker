import { Component } from '@angular/core';
import { NgxMultipleDatesModule } from 'ngx-multiple-dates'; // module import

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'example-hf';
}
