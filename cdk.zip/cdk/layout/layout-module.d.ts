import * as ɵngcc0 from '@angular/core';
export declare class LayoutModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<LayoutModule, never, never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<LayoutModule>;
}

//# sourceMappingURL=layout-module.d.ts.map