/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { FocusTrapManager as ɵangular_material_src_cdk_a11y_a11y_a } from './focus-trap/focus-trap-manager';

//# sourceMappingURL=index.d.ts.map