/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { CDK_ACCORDION as ɵangular_material_src_cdk_accordion_accordion_a } from './accordion';

//# sourceMappingURL=index.d.ts.map