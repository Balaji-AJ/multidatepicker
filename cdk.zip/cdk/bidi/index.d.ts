/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { DIR_DOCUMENT_FACTORY as ɵangular_material_src_cdk_bidi_bidi_a } from './dir-document-token';

//# sourceMappingURL=index.d.ts.map